memory = {}
byte = 8
processing_speed = 1
uptime = 0
ram = 0
avaible_ram = 0
model = "davKOMP I2 Pro Max"


import time
import os
import random
import threading 

with open("data/cpu.os", 'r') as cpu_load:
    cpu = cpu_load.read()
with open("data/memory.os", 'r') as memory_load:
    byte = int(memory_load.read())
    ram = byte * 160
    avaible_ram = ram

if cpu == "Davk core 2-bit":
    processing_speed = 1.5
elif cpu == "Davk core 4-bit":
    processing_speed = 0.75
elif cpu == "Davk core 8-bit":
    processing_speed = 0.375
else:
    processing_speed = 60

def get(val):
    result = memory.get(val)
    return result

def write(val, val2):
    memory[val] = val2

def update_uptime():
    global uptime
    while True:
        time.sleep(1)
        uptime += 1

uptime_thread = threading.Thread(target=update_uptime)
uptime_thread.start()

if byte < 17:
  print("Creating a new memory")
  time.sleep(2)
  print("davKOMP accesing memory...")
  time.sleep(0.8)
  ask = input("Boot up? Y/N > ")
  if ask == "Y":
      print("Booting up...")
      time.sleep(0.7)
      work = True
      os.system('cls')
      print("davKOMP all rights reserved")
      print("")
  else:
    print("Stopping...")
    time.sleep(processing_speed)
    os._exit(0)

  while work:
      ask = input("Command > ")
      if ask == "write":
          key = input("Enter name: ")
          value = input("Enter value: ")
          print("Operating...")
          time.sleep(processing_speed)
          write(key, value)
          print("Successfully written to memory!")
          print("")
      elif ask == "read":
          key = input("Enter key to read: ")
          print("Operating...")
          time.sleep(processing_speed)
          result = get(key)
          print("Value in memory:", result)
          print("")
      elif ask == "backup":
          work8 = True
          while work8:
              key = input("Enter key: ")
              print("Operating...")
              time.sleep(processing_speed)
              if key in memory:
                  write("backup-"+key, get(key))
                  print(f"Successfully copied {key} as backup-"+key)
                  print(" ")
                  work8 = False
              else:
                  print("Not a valid key!")
                  work8 = False
                  print(" ")
      elif ask == "export":
          file_name = input("Enter the file name to export to: ")
          print("Operating...")
          time.sleep(processing_speed)
          with open("data/memories/" + file_name + ".davk", 'w') as file:
              for key, value in memory.items():
                  file.write(f"{key}: {value}\n")
          print("Memory exported to", file_name + ".davk")
          print(" ")
      elif ask == "import":
          file_name = input("Enter the file name to import from: ")
          print("Operating...")
          time.sleep(processing_speed)
          with open("data/memories/" + file_name + ".davk", 'r') as file:
              for line in file:
                  key, value = line.strip().split(": ")
                  if key not in memory:
                      write(key, value)
              print("Memory imported from", file_name + ".davk")
              print(" ")
      elif ask == "search":
          value_to_search = input("Enter the value to search for: ")
          print("Operating...")
          time.sleep(processing_speed)
          found_keys = [key for key, value in memory.items() if value == value_to_search]
          if found_keys:
              print(f"Keys with the specified value: {', '.join(found_keys)}")
          else:
             print("No keys found with the specified value.")
          print(" ")
      elif ask == "add":
          work3 = True
          while work3:
              key = input("Enter a key: ")
              key2 = input("Enter a second key: ")
              print("Operating...")
              time.sleep(processing_speed)
              if key in memory and key2 in memory:
                  result = int(get(key)) + int(get(key2))
                  print("Result:", result)
                  print("")
                  work3 = False
              else:
                  print("One/both of the values do not exist")
                  print("")
                  work3 = False
      elif ask == "multiply":
          work4 = True
          while work4:
              key = input("Enter a key: ")
              key2 = input("Enter a second key: ")
              print("Operating...")
              time.sleep(processing_speed)
              if key in memory and key2 in memory:
                  result = int(get(key)) * int(get(key2))
                  print("Result:", result)
                  print("")
                  work4 = False
              else:
                  print("One/both of the values do not exist")
                  print("")
                  work4 = False
      elif ask == "subtract":
          work5 = True
          while work5:
              key = input("Enter a key: ")
              key2 = input("Enter a second key: ")
              print("Operating...")
              time.sleep(processing_speed)
              if key in memory and key2 in memory:
                  result = int(get(key)) - int(get(key2))
                  print("Result:", result)
                  print("")
                  work5 = False
              else:
                  print("One/both of the values do not exist")
                  print("")
                  work5 = False
      elif ask == "divide":
          work6 = True
          while work6:
              key = input("Enter a key: ")
              key2 = input("Enter a second key: ")
              print("Operating...")
              time.sleep(processing_speed)
              if key in memory and key2 in memory:
                  result = int(get(key)) / int(get(key2))
                  print("Result:", result)
                  print("")
                  work6 = False
              else:
                  print("One/both of the values do not exist")
                  print("")
                  work6 = False
      elif ask == "uptime":
          print("Current uptime:", uptime)
      elif ask == "module":
          work9 = True
          while work9:
              ask = input("Key with module: ")
              val = get(ask)
              if ask in memory and val == "mod(random)":
                  ask2 = int(input("Minimal number: "))
                  ask3 = int(input("Maximal number: "))
                  result = random.randint(ask2,ask3)
                  print("Operating...")
                  time.sleep(processing_speed)
                  print("Random number:", result)
                  print(" ")
                  work9 = False
              elif ask in memory and val == "mod(time)":
                  time_current = time.time()
                  current_time = time.localtime(time_current)
                  print("Operating...")
                  time.sleep(processing_speed)
                  print(f"{current_time.tm_hour}:{current_time.tm_min}:{current_time.tm_sec}")
                  print(" ")
                  work9 = False
              elif ask in memory and val == "mod(processing)":
                  print("Operating...")
                  time.sleep(processing_speed)
                  if cpu == "Davk core 2-bit":
                      processing_speed = 1.2
                      print("Successfully decreased processing speed by 0.3! Your processing_speed is now", processing_speed)
                  elif cpu == "Davk core 4-bit":
                      processing_speed = 0.35
                      print("Successfully decreased processing speed by 0.3! Your processing_speed is now", processing_speed)
                  elif cpu == "Davk core 8-bit":
                      processing_speed = 0.075
                      print("Successfully decreased processing speed by 0.3! Your processing_speed is now", processing_speed)
                  else:
                      processing_speed = 30
                      print("Successfully decreased processing speed by 30! Your processing speed is now", processing_speed)
                  print(" ")
                  work9 = False
              else:
                  print("Invalid module.")
                  work9 = False
      elif ask == "delete":
          work7 = True
          while work7:
              key = input("Enter a key: ")
              print("Operating...")
              time.sleep(processing_speed)
              if key in memory:
                  memory.pop(key)
                  print("Success!")
                  print(" ")
                  work7 = False
              else:
                  print("Key doesn't exist!")
                  work7 = False
      elif ask == "list":
          keys = len(memory)
          wait = keys * processing_speed
          print("Operating...")
          time.sleep(wait)
          print("Memory:")
          for key, value in memory.items():
              print(f"{key}: {value}")
          print("")
      elif ask == "clear":
          keys = len(memory)
          wait = keys * processing_speed
          memory.clear()
          print("Operating...")
          time.sleep(wait)
          print("Successfully cleared memory, it had", keys, "keys!")
          print(" ")
      elif ask == "help":
          time.sleep(processing_speed)
          print("List of operations:")
          print("write - writes a value to the memory")
          print("read - reads a value from the memory")
          print("add - basic calculation, a + b example")
          print("subtract - basic calculation, a - b example")
          print("divide - basic calculation, a / b example")
          print("multiply - basic calculation, a * b example")
          print("list - list of keys and their values")
          print("clear - clears all of the values")
          print("info - shows davKOMP info")
          print("search - searched for an key with an value")
          print("backup - backups a key as 'backup-[keyname]'")
          print("export - exports memory data for later usage, do not use file extensions")
          print("import - imports data from a file, do not use file extensions")
          print("module - uses an module")
          print("uptime - prints out current uptime in seconds")
          print("")
          print("Documentation: komp.kopal-host.xyz ")
          print("")
      elif ask == "info":
          avaible_ram = ram
          usage = 0
          print("Operating...")
          time.sleep(processing_speed)
          print(f"model: {model}")
          print("Max amount of keys in memory:", byte)
          print("Current amount of keys in memory:", len(memory))
          print("Operation speed:", processing_speed, "seconds")
          for key in memory.items():
              usage += 12.5
              avaible_ram = int(avaible_ram)
              avaible_ram -= 160
          print("Memory usage:", str(usage) + "%")
          print("avaible ram:", avaible_ram)
          print("ram:", ram)
          print(f"cpu: {cpu}")
          print("")

      else:
          print("Unknown command, use 'help' for a list of operations.")
          print("")

      keys = len(memory)
      if keys > int(byte):
          work2 = True
          while work2:
              print("Too much data in memory!")
              ask = input("Please enter a key name to delete it and free up some memory > ")
              print("Operating...")
              time.sleep(processing_speed)
              if ask in memory:
                  memory.pop(ask)
                  print("Success!")
                  print(" ")
                  work2 = False
              else:
                  print("Key not found in memory.")
                  print("")
else:
    print("System error, tried to load huge amount of bytes. Please change memory.davk to 16 or less, if you think this is an false issue then contact support.")
    work = False
    